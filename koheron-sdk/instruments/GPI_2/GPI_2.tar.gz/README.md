# Pulse generator

https://www.koheron.com/blog/2016/10/13/pulse-generator
